# Shell-Scripts
A Collection of Shell Scripts that i made
